
import subprocess
import threading
import time
import os
import sys
import platform

def start_django_server():
    system = platform.system()
    if system == "Windows":
        venv_python = os.path.join("myenv", "Scripts", "python.exe")
    else:
        venv_python = os.path.join("myenv", "bin", "python")

    subprocess.Popen([venv_python, "manage.py", "runserver"], shell=False)

def start_gui():
    system = platform.system()
    if system == "Windows":
        venv_python = os.path.join("myenv", "Scripts", "python.exe")
    else:
        venv_python = os.path.join("myenv", "bin", "python")

    subprocess.call([venv_python, os.path.join("ui", "icd_creation_tool.py")])

if __name__ == "__main__":
    django_thread = threading.Thread(target=start_django_server)
    django_thread.start()
    time.sleep(5)
    start_gui()
