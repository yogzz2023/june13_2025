from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout,
    QHBoxLayout, QStackedWidget, QListWidget, QTextEdit, QComboBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QGraphicsDropShadowEffect
)
from PyQt5.QtGui import QFont, QColor, QLinearGradient, QBrush, QPalette
from PyQt5.QtCore import Qt, QPoint
from PyQt5.Qt import *
from PyQt5 import QtCore
import sys
import json
import requests  
import os
import ast


# Modern color palette
COLORS = {
    "primary": "#4A90E2",
    "secondary": "#6A5ACD",
    "accent": "#FF6B6B",
    "background": "#F5F7FB",
    "text": "#2D3436",
    "success": "#4CAF50",
    "warning": "#FFC107",
    "error": "#EF5350"
}

class PopupWindow(QWidget):
    obj_sent = QtCore.pyqtSignal(list,str)
    edit_obj_sent = QtCore.pyqtSignal(list,str)

    def __init__(self, class_data, action):
        super().__init__()

        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)

        self.setStyleSheet(f"""
            QWidget {{
                background: {COLORS['background']};
                font-family: 'Segoe UI';
            }}
            QListWidget {{
                background: white;
                border-radius: 8px;
                border: 2px solid {COLORS['primary']};
                padding: 10px;
                font-size: 14px;
            }}
            QTableWidget {{
                background: white;
                border-radius: 8px;
                border: 2px solid {COLORS['primary']};
                alternate-background-color: #f8f9fa;
            }}
            QHeaderView::section {{
                background: {COLORS['primary']};
                color: white;
                padding: 8px;
                border: none;
            }}
            QPushButton {{
                background: {COLORS['primary']};
                color: white;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
            }}
            QPushButton:hover {{
                background: {COLORS['secondary']};
            }}
            QTextEdit {{
                background: white;
                border: 2px solid {COLORS['primary']};
                border-radius: 8px;
                padding: 8px;
            }}
            QComboBox {{
                background: white;
                border: 2px solid {COLORS['primary']};
                border-radius: 6px;
                padding: 6px;
            }}
            QLabel.error {{
                color: {COLORS['error']};
                font-style: italic;
                font-size: 12px;
            }}
        """)

        widget = QWidget()
        layout = QVBoxLayout()

        attributes_label = QLabel("Attributes:")
        attributes_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.union_attributes_table = QTableWidget(1, 7)
        self.union_attributes_table.setHorizontalHeaderLabels(
            ["Parameter", "Data Type", "Bit Count", "Min Value", "Max Value", "Default", "Actions"])
        self.union_attributes_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        add_union_button = QPushButton("Add Attributes and Exit")
        add_union_button.clicked.connect(self.add_union_attributes)
        add_union_button.setStyleSheet(f"background: {COLORS['success']};")

        exit_union_button = QPushButton("Exit without Adding")
        exit_union_button.clicked.connect(self.exit_union_button)
        exit_union_button.setStyleSheet(f"background: {COLORS['success']};")

        self.add_buttons_to_row(0)
        if(action == "editing"):
            self.edit_union_attribute(class_data)

        bottom_button_layout = QHBoxLayout()
        bottom_button_layout.addWidget(add_union_button)
        bottom_button_layout.addWidget(exit_union_button)

        layout.addWidget(attributes_label)
        layout.addWidget(self.union_attributes_table)
        layout.addLayout(bottom_button_layout)
        self.setLayout(layout)

    def edit_union_attribute(self, class_data):
        class_list = []
        data = []

        if class_data and class_data["union_data"]:
            class_list = ast.literal_eval(class_data["union_data"])

        for row , row_data in enumerate(class_list):
            data.append([row_data["parameter"], 
                        row_data["data_type"], 
                        row_data["bit_count"], 
                        row_data["min_value"], 
                        row_data["max_value"], 
                        row_data["default"], 
                    ])

        for row, row_data in enumerate(data):
            row_position = self.union_attributes_table.rowCount()

            if row_position < row+1:
                self.union_attributes_table.insertRow(row_position)

            for col, col_data in enumerate(row_data):
                if col == 6:
                    self.add_buttons(row, class_name)
                else:
                    item = QTableWidgetItem(str(col_data))
                    self.union_attributes_table.setItem(row, col, item) 

    def exit_union_button(self):
        self.obj_sent.emit([], "exit")
        self.edit_obj_sent.emit([], "exit")
        self.close()

    def add_union_attributes(self):
        print("Adding attributes to union")

        data = []
        for row in range(self.union_attributes_table.rowCount()):
            row_data = {}
            is_complete = True  

            for column in range(self.union_attributes_table.columnCount()-1): 
                header_text = self.union_attributes_table.horizontalHeaderItem(column).text()                
                item = self.union_attributes_table.item(row, column)
 
                if item:
                    row_data[header_text] = item.text()
                    if not item.text(): 
                        is_complete = False
                else:
                    is_complete = False

            if is_complete: 
                mapped_obj = {key.lower().replace(" ", "_"): value for key, value in row_data.items()}
                mapped_obj["data_type_type"]= "Standard"
                
                data.append(mapped_obj)  

        self.obj_sent.emit(data, "add") 
        self.edit_obj_sent.emit(data, "add") 
        
        self.close()

    def add_buttons_to_row(self, row):
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(5)

        add_button = QPushButton("+")
        add_button.setFixedSize(25, 25)
        add_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['success']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #449d44; }}
        """)
        add_button.clicked.connect(self.add_attribute)

        remove_button = QPushButton("×")
        remove_button.setFixedSize(25, 25)
        remove_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['error']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #c9302c; }}
        """)
        remove_button.clicked.connect(lambda _, row=row: self.remove_attribute("post", row))

        button_layout.addWidget(add_button)
        button_layout.addWidget(remove_button)

        action_widget = QWidget()
        action_widget.setLayout(button_layout)
        self.union_attributes_table.setCellWidget(row, 6, action_widget)
        
    def add_attribute(self):
        row_position = self.union_attributes_table.rowCount()

        self.union_attributes_table.insertRow(row_position)
        self.add_buttons_to_row(row_position)

    def remove_attribute(self, api, row):
        row_position = self.union_attributes_table.rowCount()
        print("row_position and row : ", row_position, row)


        if row_position != 0: 
            self.union_attributes_table.removeRow(row)  

class LoginPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent

        # Gradient background
        self.setAutoFillBackground(True)
        palette = self.palette()
        gradient = QLinearGradient(QPoint(0, 0), QPoint(800, 600))
        gradient.setColorAt(0.0, QColor("#667eea"))
        gradient.setColorAt(1.0, QColor("#764ba2"))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

        # self.setFixedSize(600, 400)
        self.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text']};
                font-size: 16px;
                font-family: 'Segoe UI';
            }}
            QLineEdit {{
                background: white;
                border: 2px solid {COLORS['primary']};
                border-radius: 8px;
                padding: 12px;
                font-size: 14px;
                color: {COLORS['text']};
                min-width: 300px;
            }}
            QPushButton {{
                background: {COLORS['primary']};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 30px;
                font-size: 14px;
                font-weight: bold;
                min-width: 120px;
            }}
            QPushButton:hover {{
                background: {COLORS['secondary']};
            }}
            QPushButton:pressed {{
                background: {COLORS['accent']};
            }}
        """)

        self.layout = QVBoxLayout()
        self.layout.setSpacing(20)
        self.layout.setContentsMargins(50, 30, 50, 30)

        # Title with shadow effect
        title_label = QLabel("ICD Creation Tool")
        title_label.setFont(QFont("Segoe UI", 24, QFont.Bold))
        title_label.setStyleSheet("color: white;")

        # Create a shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(4)
        shadow.setOffset(2, 2)
        shadow.setColor(QColor(0, 0, 0, 128))  # RGBA for semi-transparent black

        # Apply the shadow effect to the QLabel
        title_label.setGraphicsEffect(shadow)

        # Form elements
        form_layout = QVBoxLayout()
        form_layout.setSpacing(15)
        
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Password")

        # Button container
        button_layout = QHBoxLayout()
        button_layout.setSpacing(20)
        self.login_button = QPushButton("Sign In")
        self.login_button.clicked.connect(self.login)
        self.register_button = QPushButton("Register")
        self.register_button.clicked.connect(self.register)

        # Assemble layout
        form_layout.addWidget(title_label, alignment=Qt.AlignCenter)
        form_layout.addSpacing(30)
        form_layout.addWidget(self.username_input)
        form_layout.addWidget(self.password_input)
        form_layout.addSpacing(20)
        button_layout.addWidget(self.login_button)
        button_layout.addWidget(self.register_button)
        form_layout.addLayout(button_layout)

        # Glass effect container
        container = QWidget()
        container.setLayout(form_layout)
        container.setStyleSheet("""
            # background: rgba(255, 255, 255, 0.9);
            border-radius: 16px;
            padding: 30px;
        """)

        self.layout.addWidget(container)
        self.setLayout(self.layout)

    def login(self):
        username = self.username_input.text()
        password = self.password_input.text()
        if username == "admin" and password == "admin":
            self.parent.switch_to_main()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid username or password")

    def register(self):
        QMessageBox.information(self, "Register", "Registration functionality.") #we have to implement

class MainPage(QWidget):
    def __init__(self):
        super().__init__()

        self.setStyleSheet(f"""
            QWidget {{
                background: {COLORS['background']};
                font-family: 'Segoe UI';
            }}
            QListWidget {{
                background: white;
                border-radius: 8px;
                border: 2px solid {COLORS['primary']};
                padding: 10px;
                font-size: 14px;
            }}
            QTableWidget {{
                background: white;
                border-radius: 8px;
                border: 2px solid {COLORS['primary']};
                alternate-background-color: #f8f9fa;
            }}
            QHeaderView::section {{
                background: {COLORS['primary']};
                color: white;
                padding: 8px;
                border: none;
            }}
            QPushButton {{
                background: {COLORS['primary']};
                color: white;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
            }}
            QPushButton:hover {{
                background: {COLORS['secondary']};
            }}
            QTextEdit {{
                background: white;
                border: 2px solid {COLORS['primary']};
                border-radius: 8px;
                padding: 8px;
            }}
            QComboBox {{
                background: white;
                border: 2px solid {COLORS['primary']};
                border-radius: 6px;
                padding: 6px;
            }}
            QLabel.error {{
                color: {COLORS['error']};
                font-style: italic;
                font-size: 12px;
            }}
        """)

        self.layout = QHBoxLayout()
        self.options_list = QListWidget()
        self.options_list.addItems(["Add Protocol", "Create Library", "Edit Classes"])
        self.options_list.setFixedWidth(250)
        self.options_list.setFont(QFont("Segoe UI", 12))
        self.options_list.currentRowChanged.connect(self.change_option)

        self.right_widget = QStackedWidget()
        self.add_protocol_widget = self.create_add_protocol_widget()
        self.library_widget = self.create_library_widget()
        self.edit_protocol_widget = self.create_edit_protocol_widget()

        self.right_widget.addWidget(self.add_protocol_widget)
        self.right_widget.addWidget(self.library_widget)
        self.right_widget.addWidget(self.edit_protocol_widget)

        self.layout.addWidget(self.options_list)
        self.layout.addWidget(self.right_widget)
        self.setLayout(self.layout)
 
    @QtCore.pyqtSlot(list, str)
    def receiver_obj(self, obj_list, signal):
        if signal == "add" and obj_list:
            self.union_attributes_list.append([self.union_row, obj_list])

        self.opened_windows.remove(self.union_row)
        
    def create_add_protocol_widget(self):
        print("create_add_protocol_widget called\n")
        widget = QWidget()
        layout = QVBoxLayout()

        protocol_name_label = QLabel("Protocol Name:")
        protocol_name_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.protocol_name_input = QLineEdit()
        self.protocol_name_input.setPlaceholderText("Enter protocol name")
        self.protocol_name_error = QLabel("Protocol Name: Required")
        self.protocol_name_error.setObjectName("error")
        self.protocol_name_error.setVisible(False)

        protocol_type_label = QLabel("Protocol Type:")
        protocol_type_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.protocol_type_dropdown = QComboBox()
        self.protocol_type_dropdown.addItems(["Request Type", "Response Type"])

        attributes_label = QLabel("Attributes:")
        attributes_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.attributes_table = QTableWidget(1, 7)
        self.attributes_table.setHorizontalHeaderLabels(
            ["Parameter", "Data Type", "Bit Count", "Min Value", "Max Value", "Default", "Actions"])
        self.attributes_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # initial row with fixed buttons
        self.libraries_list = QListWidget()
        self.class_list = QListWidget()
        self.sub_data_type=[]
        self.data_types=[]
        self.fetching_classes()
        self.add_buttons_to_row(0,self.sub_data_type)
        self.union_attributes_list = []
        self.opened_windows = []

        self.edit_union_row = []
        self.edit_opened_windows = []
        self.edit_union_attributes_list = []

        remarks_label = QLabel("Remarks:")
        remarks_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.remarks_box = QTextEdit()

        generate_class_button = QPushButton("Generate Class")
        generate_class_button.clicked.connect(self.generate_class)
        generate_class_button.setStyleSheet(f"background: {COLORS['success']};")

        bottom_button_layout = QHBoxLayout()
        bottom_button_layout.addWidget(generate_class_button)

        layout.addWidget(protocol_name_label)
        layout.addWidget(self.protocol_name_input)
        layout.addWidget(protocol_type_label)
        layout.addWidget(self.protocol_type_dropdown)
        layout.addWidget(attributes_label)
        layout.addWidget(self.attributes_table)
        layout.addWidget(remarks_label)
        layout.addWidget(self.remarks_box)
        layout.addLayout(bottom_button_layout)

        widget.setLayout(layout)
        return widget

    def add_buttons_to_row(self, row, sub_data_type):
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(5)

        add_button = QPushButton("+")
        add_button.setFixedSize(25, 25)
        add_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['success']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #449d44; }}
        """)
        add_button.clicked.connect(self.add_attribute)

        remove_button = QPushButton("×")
        remove_button.setFixedSize(25, 25)
        remove_button.setEnabled(row != 0)
        remove_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['error']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #c9302c; }}
        """)
        remove_button.clicked.connect(lambda _, row=row: self.remove_attribute("post", row))

        self.add_attributes_button = QPushButton("Add")
        self.add_attributes_button.setFixedSize(100, 25)
        self.add_attributes_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['success']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #449d44; }}
        """)
        self.add_attributes_button.clicked.connect(lambda _, row=row: self.add_union_attributes(row))

        button_layout.addWidget(add_button)
        button_layout.addWidget(remove_button)
        button_layout.addWidget(self.add_attributes_button)

        action_widget = QWidget()
        action_widget.setLayout(button_layout)
        self.attributes_table.setCellWidget(row, 6, action_widget)
        
        data_type_dropdown = QComboBox()
        self.data_types = [
            "bool", "char", "signed char", "unsigned char", "short", "unsigned short",
            "int", "unsigned int", "long", "unsigned long", "long long", "unsigned long long",
            "float", "double", "long double", "wchar_t", "char8_t", "char16_t", "char32_t", 
            "int8_t", "int16_t", "int32_t", "union"
        ]
        for data in sub_data_type:
            self.data_types.append(data)
            
        data_type_dropdown.addItems(self.data_types)
        data_type_dropdown.setEditable(True)
        self.attributes_table.setCellWidget(row, 1, data_type_dropdown)
        
    def add_attribute(self):
        row_position = self.attributes_table.rowCount()
        self.attributes_table.insertRow(row_position)
        
        self.fetching_classes()
        self.add_buttons_to_row(row_position,self.sub_data_type)

    def remove_attribute(self, api, row):
        if api == "post":
            if row != 0:  #  disabling removing the first row
                self.attributes_table.removeRow(row)
        else:
            print("Remove this row....", row)
            self.edit_attributes_table.removeRow(row)

    def add_union_attributes(self, row):
        data_type_widget = self.attributes_table.cellWidget(row, 1)
        self.union_row = row

        if data_type_widget:
            data_type = data_type_widget.currentText()
            if data_type != "union":
                QMessageBox.warning(self, "Error", f"Can't add for non 'union' data type")
            else:
                if row in self.opened_windows:
                    QMessageBox.warning(self, "Error", f"Window for this row is already opened!")
                    return 
                else:
                    self.opened_windows.append(row)   

                    self.w = PopupWindow([], "adding")
                    self.w.setWindowTitle("ICD Creation Tool")
                    self.w.setFixedWidth(1380)
                    self.w.setFixedHeight(480)

                    # Connecting Union Popup to MainPage
                    self.w.obj_sent.connect(self.receiver_obj)

                    self.w.show()
   
    def create_library_widget(self):
        widget = QWidget()
        layout = QVBoxLayout()

        libraries_label = QLabel("Available Classes:")
        libraries_label.setFont(QFont("Arial", 12))
        self.libraries_list = QListWidget()
        self.libraries_list.setFont(QFont("Arial", 10))
        self.libraries_list.setSelectionMode(QListWidget.MultiSelection)  # Allow multiple selections

        ok_button = QPushButton("OK")
        ok_button.clicked.connect(self.generate_library)

        # delete_button = QPushButton("Delete")
        # delete_button.clicked.connect(self.delete_classes)

        layout.addWidget(libraries_label)
        layout.addWidget(self.libraries_list)
        layout.addWidget(ok_button)
        # layout.addWidget(delete_button)

        widget.setLayout(layout)
        return widget

    def change_option(self, index):
        print("change option called\n")
        self.right_widget.setCurrentIndex(index)
        if index == 1:  # If "Create Library" is selected
            self.fetching_classes() 
            
        if index == 0:  # If "Create Attribute" is selected
            self.fetching_classes()     
            
            row_position = self.attributes_table.rowCount()
            
            self.add_buttons_to_row(row_position,self.sub_data_type)

    def generate_class(self):
        # Collecting data from the table
        data = []
        self.opened_windows.clear()

        for row in range(self.attributes_table.rowCount()):

            row_data = {}
            is_complete = True  

            for column in range(self.attributes_table.columnCount() - 1): 
                header_text = self.attributes_table.horizontalHeaderItem(column).text()
                if column == 1:  
                    data_type_widget = self.attributes_table.cellWidget(row, column)
                    if data_type_widget:
                        row_data[header_text] = data_type_widget.currentText()
                        if not data_type_widget.currentText():  
                            is_complete = False
                else:
                    item = self.attributes_table.item(row, column)
                    if item:
                        row_data[header_text] = item.text()
                        if not item.text(): 
                            is_complete = False
                    else:
                        is_complete = False

            if is_complete: 
                mapped_obj = {key.lower().replace(" ", "_"): value for key, value in row_data.items()}
                mapped_obj["class_name"]= self.protocol_name_input.text()
                mapped_obj["union_data"]= []

                for union_data in self.union_attributes_list:
                    if union_data[0] == row:
                        mapped_obj["union_data"] = union_data[1]

                data.append(mapped_obj)
        
        for obj in data:
            obj["data_type_type"] =  "Sub_Type"
            
        for obj in data :
            if obj["data_type"] not in self.sub_data_type:
                obj["data_type_type"] = "Standard"  
             
        # Convert data to JSON
        
        json_data = json.dumps(data, indent=4)
        print("JSON Data to be sent:")
        print(json_data)

        # Sending JSON data to an API endpoint
        try:
            response = requests.post("http://127.0.0.1:8000/api/icd/", json=json_data)
            # print("Response from API:", response.text)
            if response.status_code == 201:
                QMessageBox.information(self, "Success", "Data sent successfully!")
                # Adding protocol name to available classes list
                self.libraries_list.addItem(self.protocol_name_input.text())
            else:
                QMessageBox.warning(self, "Error", f"Failed to send data,, {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}")
            
        self.fetching_classes()
        
        for row in range(self.attributes_table.rowCount()):  
            for column in range(self.attributes_table.columnCount() - 1):
                if column == 1:  
                    data_type_widget = self.attributes_table.cellWidget(row, column)
                    [self.data_types.append(data) for data in self.sub_data_type if data not in self.data_types]    
                        
                    data_type_dropdown = QComboBox()
                    data_type_dropdown.addItems(self.data_types)
                    data_type_dropdown.setEditable(True)
                    self.attributes_table.setCellWidget(row, 1, data_type_dropdown)
                else:    
                    item = self.attributes_table.item(row, column)
                    if item:
                        print("Data : ", row, column ,item.text())
                    else: 
                        print("No data!")   
                    
    def generate_library(self):
        selected_items = self.libraries_list.selectedItems()
        selected_class_names = [item.text() for item in selected_items]

        if not selected_class_names:
            QMessageBox.warning(self, "Error", "No classes selected.")
            return

        # Convert data to JSON
        json_data = json.dumps(selected_class_names, indent=4)
        print("JSON Data to be sent:")
        print(json_data)

        # Sending JSON data to an API endpoint
        try:
            response = requests.post("http://127.0.0.1:8000/api/library/", json=json_data)
            print("Response from API:", response.text)
            if response.status_code == 201:
                QMessageBox.information(self, "Success", "Data sent successfully!")
            else:
                # QMessageBox.warning(self, "Error", f"Failed to send data: {response.status_code}")
                QMessageBox.warning(self, "Error", f"Failed to send data,: {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}")

    def fetching_classes(self):            
        # Receiving JSON data to an API endpoint
        try:
            # Define query parameters
            query_params = {"only_class": "true"}  # Pass 'only_class' as a query parameter
            
            # Make GET request with query parameters
            response = requests.get("http://127.0.0.1:8000/api/icd/", params=query_params)
            # print("Response from API:", response.text)
            
            if response.status_code == 200:
                class_names = response.json()
                self.libraries_list.clear()  # Clear the list before adding new items
                self.libraries_list.addItems(class_names)

                self.class_list.clear()  # Clear the list before adding new items
                self.class_list.addItems(class_names)
                
                self.sub_data_type.clear()
                for class_name in class_names:
                    self.sub_data_type.append(class_name)
                    
                print(self, "Success", "Data received successfully!")
            else:
                print(self, "Error", f"Failed to receive data: {response.status_code}")
    
        except requests.exceptions.RequestException as e:
            print(self, "Error", f"An error occurred: {e}") 

    # Methods for Editing a Existing Class
    @QtCore.pyqtSlot(list, str)
    def receiver_edit_obj(self, obj_list, signal):
        print("Object list ------ ", obj_list)
        print("\n-------------------------\n")
        print("edit_union_list : ", self.edit_union_attributes_list)

        if signal == "add" and obj_list:
            mark = False
            cnt =0
            for union_data in self.edit_union_attributes_list:
                if union_data[0] == self.edit_union_row:
                    mark = True
                    self.edit_union_attributes_list[cnt].remove(self.edit_union_row)
                    self.edit_union_attributes_list.append([self.edit_union_row, obj_list])
                    break
                cnt+=1    

            if mark == False:
                self.edit_union_attributes_list.append([self.edit_union_row, obj_list])

        self.edit_opened_windows.remove(self.edit_union_row)

    def create_edit_protocol_widget(self):
        widget = QWidget()
        layout = QVBoxLayout()

        self.fetched_class_data = []
        self.selected_class_name = []
        
        libraries_label = QLabel("Available Classes:")
        libraries_label.setFont(QFont("Arial", 12))
        self.class_list = QListWidget()
        self.class_list.setFont(QFont("Arial", 10))
        self.class_list.itemClicked.connect(self.fetching_class_to_edit)

        attributes_label = QLabel("Attributes:")
        attributes_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.edit_attributes_table = QTableWidget(1, 7)
        self.edit_attributes_table.setHorizontalHeaderLabels(
            ["Parameter", "Data Type", "Bit Count", "Min Value", "Max Value", "Default", "Delete"])
        self.edit_attributes_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        add_button = QPushButton("Add Attribute")
        add_button.clicked.connect(self.add_new_attribute)
        add_button.setStyleSheet(f"background: {COLORS['success']};")

        update_button = QPushButton("Update Class")
        update_button.clicked.connect(self.update_class)
        update_button.setStyleSheet(f"background: {COLORS['success']};")

        button_layout = QHBoxLayout()
        button_layout.addWidget(add_button)
        button_layout.addWidget(update_button)
        
        layout.addWidget(libraries_label)
        layout.addWidget(self.class_list)
        layout.addWidget(self.edit_attributes_table)
        layout.addLayout(button_layout)

        widget.setLayout(layout)
        return widget

    def fetching_class_to_edit(self):
        selected_items = self.class_list.selectedItems()
        selected_class_names = [item.text() for item in selected_items]
        json_data = json.dumps(selected_class_names, indent=4)
 
        self.selected_class_name.clear() 
        self.selected_class_name.append(selected_class_names[0])

        # Sending JSON data to an API endpoint
        try:
            response = requests.get("http://127.0.0.1:8000/api/edit/", json=json_data)
            
            if response.status_code == 200:
                self.fetched_class_data.clear()
                self.fetched_class_data.append(response.json())
                
                self.edit_class(selected_class_names) 
                QMessageBox.information(self, "Success", "Data sent successfully!")
            else:
                QMessageBox.warning(self, "Error", f"Failed to send data,: {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}") 

    def add_buttons(self, row, class_name):
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(5)

        remove_button = QPushButton("×")
        remove_button.setFixedSize(25, 25)
        remove_button.setEnabled(row != 0)
        remove_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['error']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #c9302c; }}
        """)
        remove_button.clicked.connect(lambda _, row=row: self.remove_attribute("put", row))

        edit_button = QPushButton("Edit")
        edit_button.setFixedSize(100, 25)
        edit_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['error']};
                border-radius: 4px;
            }}
            QPushButton:hover {{ background: #c9302c; }}
        """)
        edit_button.clicked.connect(lambda _, row=row: self.edit_union_attribute(row, class_name))

        button_layout.addWidget(remove_button)
        button_layout.addWidget(edit_button)

        action_widget = QWidget()
        action_widget.setLayout(button_layout)
        self.edit_attributes_table.setCellWidget(row, 6, action_widget)

    def add_new_attribute(self):
        row_position = self.edit_attributes_table.rowCount()
        self.edit_attributes_table.insertRow(row_position) 
        self.add_buttons(row_position, self.selected_class_name)       

    def clear_attribute(self):
        row_count = self.edit_attributes_table.rowCount()
        
        for row in range(row_count) :
            self.edit_attributes_table.removeRow(row_count-row)
            row_count1 = self.edit_attributes_table.rowCount()

    def edit_union_attribute(self, row, class_name):
        data_type_widget = self.edit_attributes_table.item(row, 1)

        class_data = self.fetched_class_data[0][class_name[0]][row]
        self.edit_union_row = row

        if data_type_widget:
            data_type = data_type_widget.text()

            if data_type != "union":
                QMessageBox.warning(self, "Error", f"Can't add for non 'union' data type")
            else:
                if row in self.edit_opened_windows:
                    QMessageBox.warning(self, "Error", f"Window for this row is already opened!")
                    return 
                else:
                    self.edit_opened_windows.append(row)   
                    
                    self.w = PopupWindow(class_data, "editing")
                    self.w.setWindowTitle("ICD Creation Tool")
                    self.w.setFixedWidth(1380)
                    self.w.setFixedHeight(480)

                    # Connecting Union Popup to MainPage
                    self.w.edit_obj_sent.connect(self.receiver_edit_obj)

                    self.w.show()

    def edit_class(self, class_name):
        class_data = [list(d.values()) for d in self.fetched_class_data[0][class_name[0]]]

        data = []

        for row , row_data in enumerate(class_data):
            data.append([row_data[1], 
                        row_data[2], 
                        row_data[3], 
                        row_data[4], 
                        row_data[5], 
                        row_data[6], 
                        row_data[7],
                    ])

            if row_data[10] :
                union_data = ast.literal_eval(row_data[10])
                self.edit_union_attributes_list.append([row, union_data])     

        self.clear_attribute()

        for row, row_data in enumerate(data):
            row_position = self.edit_attributes_table.rowCount()

            if row_position < row+1:
                self.edit_attributes_table.insertRow(row_position)

            for col, col_data in enumerate(row_data):
                if col == 6:
                    self.add_buttons(row, class_name)
                else:
                    item = QTableWidgetItem(str(col_data))
                    self.edit_attributes_table.setItem(row, col, item) 
        
    def update_class(self):
        # print("updating class : ", self.selected_class_name)

        print("row count : ", self.edit_attributes_table.rowCount())
        
        data = []
        self.edit_opened_windows.clear()

        for row in range(self.edit_attributes_table.rowCount()):
            row_data = {}
            is_complete = True  

            for column in range(self.edit_attributes_table.columnCount()-1): 
                header_text = self.edit_attributes_table.horizontalHeaderItem(column).text()                
                item = self.edit_attributes_table.item(row, column)

                if item:
                    row_data[header_text] = item.text()
                    if not item.text(): 
                        is_complete = False
                else:
                    is_complete = False

            if is_complete: 
                mapped_obj = {key.lower().replace(" ", "_"): value for key, value in row_data.items()}
                mapped_obj["class_name"]= self.selected_class_name[0]
                mapped_obj["data_type_type"]= "Sub_Type"
                
                if mapped_obj["data_type"] not in self.sub_data_type:
                    mapped_obj["data_type_type"] = "Standard"

                for union_data in self.edit_union_attributes_list:
                    if union_data[0] == row:
                        mapped_obj["union_data"] = union_data[1]   
                
                data.append(mapped_obj)  

        self.edit_union_attributes_list.clear() 

        json_data = json.dumps([self.selected_class_name[0], data], indent=4)
        
        try:
            response = requests.put("http://127.0.0.1:8000/api/edit/", json=json_data)
            # print("Response from API : ", response.text)
            if response.status_code == 201:
                QMessageBox.information(self, "Success", "Data sent successfully!")
            else:
                QMessageBox.warning(self, "Error", f"Failed to send data,, {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}")                    

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ICD Creation Tool")
        self.setFixedWidth(1580)
        self.setStyleSheet(f"""
            QMainWindow {{
                background: {COLORS['background']};
            }}
            QStatusBar {{
                background: {COLORS['primary']};
                color: white;
            }}
        """)
         
        self.stacked_widget = QStackedWidget()

        self.login_page = LoginPage(self)
        self.main_page = MainPage()

        self.stacked_widget.addWidget(self.login_page)
        self.stacked_widget.addWidget(self.main_page)

        self.setCentralWidget(self.stacked_widget)

    
    def switch_to_main(self):
        self.stacked_widget.setCurrentWidget(self.main_page)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())