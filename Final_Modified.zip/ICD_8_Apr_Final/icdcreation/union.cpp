#include <iostream>
#include <bitset>
#include <cstdint>

using namespace std;

union Data {
    struct {
        uint8_t val_4a : 4;
        uint8_t val_4b : 4;
        uint8_t val_8a : 8;
        uint8_t val_8b : 8;
        uint8_t val_8c : 8;
    } parts;

    uint32_t combinedData;

    Data() : combinedData(0){};
} data;

int main()
{
    Data data;

    data.parts.val_4a = 15;
    data.parts.val_4b = 8;
    data.parts.val_8a = 100;
    data.parts.val_8b = 200;
    data.parts.val_8c = 255;

    cout<<"val_4a : "<<+data.parts.val_4a<<endl;
    cout<<"val_4b : "<<+data.parts.val_4b<<endl;
    cout<<"val_8a : "<<+data.parts.val_8a<<endl;
    cout<<"val_8b : "<<+data.parts.val_8b<<endl;
    cout<<"val_8c : "<<+data.parts.val_8c<<endl;

    cout<<"Combined_data : "<<std::bitset<32>(data.combinedData);
    return 0;
}