#include<bits/stdc++.h>
using namespace std;

int main()
{
    union test {
        
        struct tst{
            uint8_t x:4;        
            uint8_t z:4;        
        }b;

        uint8_t a;

    };

    test t;
    t.b.x = 0x5;
    t.b.z= 0x6;
    
    
    cout<< "Dec Value : " << +t.a << endl;
    cout<< "Hex Value : " << std::hex<<+(t.a) << endl;
    cout<< "Bit Value : " << std::bitset<8>(t.a) << endl;
    
    cout<<+t.b.x<<" "<<+t.b.z<<endl<<endl;

    union dummy {
        uint8_t x:4;        
        uint8_t z:4;        
        uint8_t a;
    };

    dummy d;
    d.x = 4;
    d.z = 5;

    cout<< "Dec Value : " << +d.a << endl;
    cout<< "Hex Value : " << std::hex<<+(d.a) << endl;
    cout<< "Bit Value : " << std::bitset<8>(d.a) << endl;

    cout<<+d.x<<" "<<+d.z<<endl;


    return 0;
}