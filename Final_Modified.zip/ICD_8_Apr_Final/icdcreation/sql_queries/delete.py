import sqlite3

conn = sqlite3.connect("icd.db")
cursor = conn.cursor

user_id = 4
cursor.execute("Delete from user where id = ?", (user_id))
conn.commit()
conn.close()