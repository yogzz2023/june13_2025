Step 1: Install Django:
pip install django

Step 2: Create a Django Project
- Create a new Django project:
    django-admin startproject myproject
- Navigate into the project folder:
    cd myproject

Step 3: Create a Django App
-  Create an app within the project:
    python manage.py startapp api
- Add the app to the INSTALLED_APPS list in the settings.py file:
    INSTALLED_APPS = [
        ...,
        'api',
    ]

Step 4: Install Django REST Framework:
- Install Django REST Framework:
    pip install djangorestframework
- Add it to INSTALLED_APPS:
    INSTALLED_APPS = [
        ...,
        'rest_framework',
    ]

Step 5: Create a Model
- In the api/models.py file, define your data model:
- Run migrations:
    python manage.py makemigrations
    python manage.py migrate

Step 6: Create a Serializer
- Create a serializers.py file in the api app and define a serializer:

Step 7: Create a View
- In the api/views.py file, define your API views:

Step 8: Configure URLs
- Create a urls.py file in the api app and define your API routes:
- Include the api app URLs in the project's urls.py:

Step 9: Test the API
- Run the Django development server:
- Access the API endpoints at: http://127.0.0.1:8000/api/

#### Command to create Library from .h and .cpp file ####

Command 1: library_name.o here library_name is the name you want to give to your library
- $ g++ -c cpp_file.cpp -o library_name.o     

Command 2: liblibrary_name.a here lib is key-word and library_name is the given library name
- $ ar rcs liblibrary_name.a library_name.o    

Command 3: -llibrary_name here -l is key-word and library_name is the given library name
- $ g++ main.cpp -L. -llibrary_name -o test    

Command 4: test here is the executable file , name is user defined in above command
- $ ./test                                     
