from rest_framework import serializers
from .models import Item,Icd

class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = '__all__'

class IcdSerializer(serializers.ModelSerializer):
    class_name = serializers.CharField(max_length=250, required=True)
    parameter = serializers.CharField(max_length=250, required=True)
    data_type = serializers.CharField(max_length=250, required=True)
    bit_count = serializers.CharField(max_length=250, required=False)
    min_value = serializers.CharField(max_length=250, required=True)
    max_value = serializers.CharField(max_length=250, required=True)
    data_type_type = serializers.CharField(max_length=250, required=False)
    union_data = serializers.ListField(max_length=250, required=False)
    default = serializers.CharField(max_length=250, required=False, allow_blank=True)

    class Meta:
        model = Icd
        fields = '__all__'

    def validate(self, data):
        # Any additional validation logic can go here
        return data
