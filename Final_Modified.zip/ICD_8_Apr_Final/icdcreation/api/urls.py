from django.urls import path
from .views import ClassCreation, LibraryCreation, ClassEdition

urlpatterns = [
    path('icd/', ClassCreation.as_view(), name='icd-creation-and-view'),
    path('library/', LibraryCreation.as_view(), name='library-creation-and-view'),
    path('edit/', ClassEdition.as_view(), name='icd-class-edition'),
]
