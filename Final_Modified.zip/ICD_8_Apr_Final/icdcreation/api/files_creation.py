import os
import ast
import subprocess
# Mapping of JSON data types to C++ data types and network conversion functions
DATA_TYPE_MAP = {
    "bool": {"cpp_type": "bool", "convert_func": "ntohs"},
    "char": {"cpp_type": "char", "convert_func": "ntohs"},
    "signed char": {"cpp_type": "signed char", "convert_func": "ntohs"},
    "unsigned char": {"cpp_type": "unsigned char", "convert_func": "ntohs"},
    "short": {"cpp_type": "short", "convert_func": "ntohs"},
    "unsigned short": {"cpp_type": "unsigned short", "convert_func": "ntohs"},
    "int": {"cpp_type": "int", "convert_func": "ntohl"},
    "unsigned int": {"cpp_type": "unsigned int", "convert_func": "ntohl"},
    "long": {"cpp_type": "long", "convert_func": "ntohl"},
    "unsigned long": {"cpp_type": "unsigned long", "convert_func": "ntohl"},
    "long long": {"cpp_type": "long long", "convert_func": "ntohll"},
    "unsigned long long": {"cpp_type": "unsigned long long", "convert_func": "ntohll"},
    "float": {"cpp_type": "float", "convert_func": "ntohs"},
    "double": {"cpp_type": "double", "convert_func": "ntohs"},
    "long double": {"cpp_type": "long double", "convert_func": "ntohs"},
    "wchar_t": {"cpp_type": "wchar_t", "convert_func": "ntohs"},
    "char8_t": {"cpp_type": "char8_t", "convert_func": "ntohs"},
    "char16_t": {"cpp_type": "char16_t", "convert_func": "ntohs"},
    "char32_t": {"cpp_type": "char32_t", "convert_func": "ntohs"},
    "int8_t": {"cpp_type": "int8_t", "convert_func": "ntohs"},
    "int16_t": {"cpp_type": "int16_t", "convert_func": "ntohs"},
    "int32_t": {"cpp_type": "int32_t", "convert_func": "ntohs"},
    "union": {"cpp_type": "union", "convert_func": "ntohs"},
}

class FilesCreation:
    def __init__(self) :
        pass
        # print("---------------------------")
              
    def create_header_files(self, data):
        # print("Creating class files...")
        base_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.join(base_dir, "src")
        inc_dir = os.path.join(base_dir, "src")
        os.makedirs(src_dir, exist_ok=True)
        os.makedirs(inc_dir, exist_ok=True)

        for class_name, attributes in data.items():
            header_filename = os.path.join(inc_dir, f"{class_name}.h")

            # ---------------- Create Header File (.h) ----------------
            with open(header_filename, "w") as header_file:
                sub_type_headers = []
               
                for attr in attributes:
                    if attr['data_type_type'] == "Sub_Type":
                        sub_type_headers.append(attr["data_type"])   
                        
                # Header Guards
                header_file.write(f"// File : {class_name}.h \n")
                header_file.write("#ifndef __{}_H__\n".format(class_name.upper()))
                header_file.write("#define __{}_H__\n\n".format(class_name.upper()))
                
                # Include necessary headers
                header_file.write("#include <stdio.h>\n")
                header_file.write("#include <cstdint>\n")
                
                # iterate for loop to add all sub_type_header
                for headers in sub_type_headers:
                    header_file.write(f"#include \"{headers}.h\"\n")
                    
                header_file.write("\n#pragma pack(1)\n\n")
              
                # Class definition
                header_file.write(f"class {class_name} {{\n")
                header_file.write("public:\n")

                # Struct definition
                header_file.write("    struct MsgBody {\n")
            
                # Dynamically add attributes
                for attr in attributes:
                    if attr['data_type_type'] == "Sub_Type":
                        cpp_type = attr["data_type"]
                    else:
                        cpp_type = DATA_TYPE_MAP.get(attr["data_type"], {"cpp_type": "unsigned short"})["cpp_type"]
                    
                    if cpp_type == "union":
                        header_file.write(f"        {"union"} {attr['parameter']} {{ \n")
                        header_file.write(f"            {"struct"} {attr['parameter']}_struct {{ \n")

                        union_list = ast.literal_eval(attr["union_data"])
                        
                        for data in union_list:
                            header_file.write(f"                {data["data_type"]} {data['parameter']}:{data['bit_count']}; // {data['bit_count']} bits \n")

                        header_file.write(f"            }} parts; \n\n")
                        header_file.write(f"            int{attr['bit_count']}_t combined; // {attr['bit_count']} bits \n\n")
                        header_file.write(f"        }} {attr['parameter']}_data; \n\n")   
                    else:    
                        header_file.write(f"        {cpp_type} {attr['parameter']}; // {attr['bit_count']} bits \n")

                # Add `print` and `printBrief` functions inside `MsgBody`
                header_file.write("\n        // Print Functions\n")
                header_file.write("        void print(char pstr[], int len);\n")
                header_file.write("        void printBrief(char pstr[], int len);\n")

                header_file.write("    } msg;\n\n")

                # Manually Defined Function Declarations
                functions = [
                    "bool set(unsigned char msg[], unsigned short &size)",
                    "bool decode(unsigned char msg[], unsigned short size)",
                    "bool isValid()",
                    "void ntoh()",
                    "void hton()",
                    "void print(char pstr[], int len)",
                    "void print(FILE *fp)",
                    "void print()",
                    "void printBrief(char pstr[], int len)",
                    "void printBrief(FILE *fp)",
                    "void printBrief()",
                    "void printMin(char pstr[], int len)",
                ]

                for func in functions:
                    header_file.write(f"    {func};\n")

                header_file.write(f"    {class_name}();\n")  # Constructor

                header_file.write("};\n\n")
                header_file.write("#pragma pack()\n\n")
                header_file.write("#endif\n")

            # print(f"Header file '{header_filename}' created successfully!")
        
    def create_cpp_file(self, data):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.join(base_dir, "src")
        lib_dir = os.path.join(base_dir, "lib")


        if not os.path.exists(lib_dir):
            os.mkdir(lib_dir)
        if not os.path.exists(src_dir):
            os.mkdir(src_dir)    

        object_files = []
        
        for class_name, attributes in data.items():

            source_filename = os.path.join(src_dir, f"{class_name}.cpp")

            with open(source_filename, "w") as source_file:
                source_file.write(f"// File : {class_name}.cpp \n")
                source_file.write(f"#include \"{class_name}.h\"\n")
                source_file.write("#include <string.h>\n")
                source_file.write("#include <stdio.h>\n")
                source_file.write("#include <stddef.h>\n")
                source_file.write("#include <iostream>\n")
                source_file.write("#include <winsock2.h>\n")
                source_file.write("using namespace std;\n\n")
                
                # Constructor Implementation
                source_file.write(f"{class_name}::{class_name}() {{\n")
                source_file.write("    memset(&msg, 0, sizeof(msg));\n")
                source_file.write("}\n\n")

                # set() function
                source_file.write(f"bool {class_name}::set(unsigned char msgbuf[], unsigned short &size) {{\n")
                source_file.write("    size = sizeof(msg);\n")
                source_file.write("    bool valid = true;\n")
                source_file.write("    hton();\n")
                source_file.write("    memcpy(msgbuf, &msg, sizeof(msg));\n")
                source_file.write("    ntoh();\n")
                source_file.write("    return valid;\n")
                source_file.write("}\n\n")

                # decode() function
                source_file.write(f"bool {class_name}::decode(unsigned char msgbuf[], unsigned short size) {{\n")
                source_file.write("    int s=0;\n")
                source_file.write("    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;\n")
                source_file.write("    memcpy(&msg, msgbuf, minSize);\n")
                source_file.write("    s+=sizeof(msg);\n")
                source_file.write("    ntoh();\n")
                source_file.write("    bool valid=true;\n")
                source_file.write("    if(s!=size) valid=false;\n")
                source_file.write("    if(!isValid()) valid=false;\n")
                source_file.write("    return valid;\n")
                source_file.write("}\n\n")

                # isValid() function
                source_file.write(f"bool {class_name}::isValid() {{\n")
                source_file.write("    return true;\n")
                source_file.write("}\n\n")

                # ntoh() function
                source_file.write(f"void {class_name}::ntoh() {{\n")
                for attr in attributes:
                    if attr['data_type_type'] == "Sub_Type":
                        source_file.write(f"    msg.{attr['parameter']}.ntoh();\n")
                    elif attr["data_type"] == "union":
                        union_list = ast.literal_eval(attr["union_data"])
                        for data in union_list:
                            source_file.write(f"    msg.{attr['parameter']}_data.parts.{data['parameter']} = ntohs(msg.{attr['parameter']}_data.parts.{data['parameter']});\n")
                        source_file.write(f"    msg.{attr['parameter']}_data.combined = ntohs(msg.{attr['parameter']}_data.combined);\n")         
                    else:
                        source_file.write(f"    msg.{attr['parameter']} = ntohs(msg.{attr['parameter']});\n")
                source_file.write("}\n\n")

                # hton() function
                source_file.write(f"void {class_name}::hton() {{\n")
                source_file.write("    ntoh();\n")
                source_file.write("}\n\n")

                # print() functions
                source_file.write(f"void {class_name}::print(char pstr[], int len) {{\n")
                source_file.write("    msg.print(pstr, len);\n")
                source_file.write("}\n\n")

                source_file.write(f"void {class_name}::print(FILE *fp) {{\n")
                source_file.write("    const int len = 4096;\n")
                source_file.write("    char str[len];\n")
                source_file.write("    print(str, len);\n")
                source_file.write("    fprintf(fp, \"%s\", str);\n")
                source_file.write("}\n\n")

                source_file.write(f"void {class_name}::print() {{\n")
                source_file.write("    print(stdout);\n")
                source_file.write("}\n\n")

                # printBrief() functions
                source_file.write(f"void {class_name}::printBrief(char pstr[], int len) {{\n")
                source_file.write("    msg.printBrief(pstr, len);\n")
                source_file.write("}\n\n")

                source_file.write(f"void {class_name}::printBrief(FILE *fp) {{\n")
                source_file.write("    const int len = 4096;\n")
                source_file.write("    char str[len];\n")
                source_file.write("    printBrief(str, len);\n")
                source_file.write("    fprintf(fp, \"%s\", str);\n")
                source_file.write("}\n\n")

                source_file.write(f"void {class_name}::printBrief() {{\n")
                source_file.write("    printBrief(stdout);\n")
                source_file.write("}\n\n")

                # printMin() function
                source_file.write(f"void {class_name}::printMin(char pstr[], int len) {{\n")
                source_file.write("    printBrief(pstr, len);\n")
                source_file.write("    char last = ' ';\n")
                source_file.write("    for (int i = len - 1; i > 0; i--) {\n")
                source_file.write("        if (pstr[i] == last && last == ' ') {\n")
                source_file.write("            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];\n")
                source_file.write("        }\n")
                source_file.write("        last = pstr[i];\n")
                source_file.write("    }\n")
                source_file.write("}\n\n")

                # ---------------- print() Function ----------------
                source_file.write(f"void {class_name}::MsgBody::print(char pstr[], int len) {{\n")
                source_file.write("    char temp[len];\n")
                source_file.write("    temp[0] = '\\0';\n")
                source_file.write("    strncpy(pstr, \"\", len);\n")
                source_file.write(f"    snprintf(temp, len, \"{class_name}:\");\n")
                source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")
                
                # Dynamically add print lines for attributes
                for attr in attributes:
                    if attr['data_type_type'] == "Sub_Type":
                        source_file.write(f"    {attr['parameter']}.print(temp, len);\n")
                        source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")
                    elif attr["data_type"] == "union":
                        union_list = ast.literal_eval(attr["union_data"])
                        for data in union_list:
                            source_file.write(f"    snprintf(temp, len, \"{attr['parameter']}_data.parts.{data['parameter']}:%d \", (int)this->{attr['parameter']}_data.parts.{data['parameter']});\n")
                            source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")
                        source_file.write(f"    snprintf(temp, len, \"{attr['parameter']}_data.combined):%d \", (int)this->{attr['parameter']}_data.combined);\n")
                        source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")                                
                    else:
                        source_file.write(f"    snprintf(temp, len, \"{attr['parameter']}:%d \", (int)this->{attr['parameter']});\n")
                        source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")
 
                source_file.write("}\n\n")

                # ---------------- printBrief() Function ----------------
                source_file.write(f"void {class_name}::MsgBody::printBrief(char pstr[], int len) {{\n")
                source_file.write("    char temp[len];\n")
                source_file.write("    temp[0] = '\\0';\n")
                source_file.write("    strncpy(pstr, \"\", len);\n")
                source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")

                # Dynamically add print lines for attributes
                for attr in attributes:
                    if attr['data_type_type'] == "Sub_Type":
                        source_file.write(f"    {attr['parameter']}.printBrief(temp, len);\n")
                        source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")
                    elif attr["data_type"] == "union":
                        union_list = ast.literal_eval(attr["union_data"])
                        for data in union_list:
                            source_file.write(f"    snprintf(temp, len, \"%d \", (int)this->{attr['parameter']}_data.parts.{data['parameter']});\n")
                            source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")
                        source_file.write(f"    snprintf(temp, len, \"%d \", (int)this->{attr['parameter']}_data.combined);\n")
                        source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")                            
                    else:
                        source_file.write(f"    snprintf(temp, len, \"%d \", (int)this->{attr['parameter']});\n")
                        source_file.write("    strncat(pstr, temp, len-strlen(pstr));\n")

                source_file.write("}\n\n")
            
            obj_file = os.path.join(src_dir, f"{class_name}.o")
            compile_command = ["g++", "-c", source_filename, "-o", obj_file]
            try:
                subprocess.run(compile_command, check=True)
                object_files.append(obj_file)
                print("----------------------")
                print(object_files)
            except subprocess.CalledProcessError as e:
                print(f"Error compiling {source_filename}: {e}")
                
            # print(f"Source file '{source_filename}' created successfully!")
    

        # Create a static library (.a)
        static_lib_path = os.path.join(lib_dir, "libclasses.a")
        ar_command = ["ar", "rcs", static_lib_path] + object_files
        try:
            subprocess.run(ar_command, check=True)
            print(f"Static library created at {static_lib_path}")
        except subprocess.CalledProcessError as e:
            print(f"Error creating static library: {e}")

        # print(object_files)
        # Create a shared library (.so)
        shared_lib_path = os.path.join(lib_dir, "libclasses.so")
        shared_command = ["g++", "-shared", "-o", shared_lib_path] + object_files
        try:
            subprocess.run(shared_command, check=True)
            print(f"Shared library created at {shared_lib_path}")
        except subprocess.CalledProcessError as e:
            print(f"Error creating shared library: {e}")
             

