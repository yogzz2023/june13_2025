// File : RDR_HDR_API.h 
#ifndef __RDR_HDR_API_H__
#define __RDR_HDR_API_H__

#include <stdio.h>

#pragma pack(1)

class RDR_HDR_API {
public:
    struct MsgBody {
        char16_t SRC; // Number of bits 16 
        char16_t DST; // Number of bits 16 
        char16_t OPCODE; // Number of bits 16 
        char16_t MSGLEN; // Number of bits 16 
        char32_t SEQNUM; // Number of bits 32 
        char16_t SYNC; // Number of bits 16 
        char16_t FLAGS; // Number of bits 16 
        char32_t TIME; // Number of bits 32 
        char16_t NSBC; // Number of bits 16 
        char16_t ACK; // Number of bits 16 
        char16_t Reserved; // Number of bits 16 
        char16_t CHKSUM; // Number of bits 16 

        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    RDR_HDR_API();
};

#pragma pack()

#endif
