// File : test1.cpp 
#include "test1.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

test1::test1() {
    memset(&msg, 0, sizeof(msg));
}

bool test1::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool test1::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool test1::isValid() {
    return true;
}

void test1::ntoh() {
    msg.msgid = ntohs(msg.msgid);
}

void test1::hton() {
    ntoh();
}

void test1::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void test1::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void test1::print() {
    print(stdout);
}

void test1::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void test1::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void test1::printBrief() {
    printBrief(stdout);
}

void test1::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void test1::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "test1:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "msgid:%d ", (int)this->msgid);
    strncat(pstr, temp, len-strlen(pstr));
}

void test1::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->msgid);
    strncat(pstr, temp, len-strlen(pstr));
}

