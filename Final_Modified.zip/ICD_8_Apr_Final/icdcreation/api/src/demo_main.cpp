#include<bits/stdc++.h>
#include "demo.h"

using namespace std;

int main()
{
    demo temp;
    
    temp.msg.first_data.parts.x = 3;
    temp.msg.first_data.parts.y = 2;
    temp.msg.first_data.parts.z = 14;
    temp.msg.first_data.parts.m = 157;

    cout<< "binary value  : ";
    cout<< std::bitset<2>(temp.msg.first_data.parts.x) <<"  ";
    cout<< std::bitset<2>(temp.msg.first_data.parts.y) <<"  ";
    cout<< std::bitset<4>(temp.msg.first_data.parts.z) <<"  ";
    cout<< std::bitset<8>(temp.msg.first_data.parts.m) <<endl;

    cout<< "decimal value : ";
    cout<< +temp.msg.first_data.parts.x <<"  ";
    cout<< +temp.msg.first_data.parts.y <<"  ";
    cout<< +temp.msg.first_data.parts.z <<"  ";
    cout<< +temp.msg.first_data.parts.m <<endl;

    cout<< "Bit Value : " << std::bitset<16>(temp.msg.first_data.combined) << endl;
}

