// File : RDR_RTGU_PWON_API.cpp 
#include "RDR_RTGU_PWON_API.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

RDR_RTGU_PWON_API::RDR_RTGU_PWON_API() {
    memset(&msg, 0, sizeof(msg));
}

bool RDR_RTGU_PWON_API::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool RDR_RTGU_PWON_API::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool RDR_RTGU_PWON_API::isValid() {
    return true;
}

void RDR_RTGU_PWON_API::ntoh() {
    msg.HDR.ntoh();
    msg.RTGU_SB.ntoh();
}

void RDR_RTGU_PWON_API::hton() {
    ntoh();
}

void RDR_RTGU_PWON_API::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void RDR_RTGU_PWON_API::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void RDR_RTGU_PWON_API::print() {
    print(stdout);
}

void RDR_RTGU_PWON_API::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void RDR_RTGU_PWON_API::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void RDR_RTGU_PWON_API::printBrief() {
    printBrief(stdout);
}

void RDR_RTGU_PWON_API::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void RDR_RTGU_PWON_API::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "RDR_RTGU_PWON_API:");
    strncat(pstr, temp, len-strlen(pstr));
    HDR.print(temp, len);
    strncat(pstr, temp, len-strlen(pstr));
    RTGU_SB.print(temp, len);
    strncat(pstr, temp, len-strlen(pstr));
}

void RDR_RTGU_PWON_API::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    HDR.printBrief(temp, len);
    strncat(pstr, temp, len-strlen(pstr));
    RTGU_SB.printBrief(temp, len);
    strncat(pstr, temp, len-strlen(pstr));
}

