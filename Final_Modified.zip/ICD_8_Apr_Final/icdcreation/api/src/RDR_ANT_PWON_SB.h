// File : RDR_ANT_PWON_SB.h 
#ifndef __RDR_ANT_PWON_SB_H__
#define __RDR_ANT_PWON_SB_H__

#include <stdio.h>

#pragma pack(1)

class RDR_ANT_PWON_SB {
public:
    struct MsgBody {
        char16_t SBLK_MSGID; // Number of bits 16 
        char16_t SBLK_LEN; // Number of bits 16 
        char16_t TRG_ID; // Number of bits 16 
        char16_t TRM_ID; // Number of bits 16 

        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    RDR_ANT_PWON_SB();
};

#pragma pack()

#endif
