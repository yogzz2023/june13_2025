// File : RDR_HDR_API.cpp 
#include "RDR_HDR_API.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

RDR_HDR_API::RDR_HDR_API() {
    memset(&msg, 0, sizeof(msg));
}

bool RDR_HDR_API::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool RDR_HDR_API::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool RDR_HDR_API::isValid() {
    return true;
}

void RDR_HDR_API::ntoh() {
    msg.SRC = ntohs(msg.SRC);
    msg.DST = ntohs(msg.DST);
    msg.OPCODE = ntohs(msg.OPCODE);
    msg.MSGLEN = ntohs(msg.MSGLEN);
    msg.SEQNUM = ntohs(msg.SEQNUM);
    msg.SYNC = ntohs(msg.SYNC);
    msg.FLAGS = ntohs(msg.FLAGS);
    msg.TIME = ntohs(msg.TIME);
    msg.NSBC = ntohs(msg.NSBC);
    msg.ACK = ntohs(msg.ACK);
    msg.Reserved = ntohs(msg.Reserved);
    msg.CHKSUM = ntohs(msg.CHKSUM);
}

void RDR_HDR_API::hton() {
    ntoh();
}

void RDR_HDR_API::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void RDR_HDR_API::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void RDR_HDR_API::print() {
    print(stdout);
}

void RDR_HDR_API::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void RDR_HDR_API::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void RDR_HDR_API::printBrief() {
    printBrief(stdout);
}

void RDR_HDR_API::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void RDR_HDR_API::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "RDR_HDR_API:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "SRC:%d ", (int)this->SRC);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "DST:%d ", (int)this->DST);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "OPCODE:%d ", (int)this->OPCODE);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "MSGLEN:%d ", (int)this->MSGLEN);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "SEQNUM:%d ", (int)this->SEQNUM);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "SYNC:%d ", (int)this->SYNC);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "FLAGS:%d ", (int)this->FLAGS);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "TIME:%d ", (int)this->TIME);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "NSBC:%d ", (int)this->NSBC);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "ACK:%d ", (int)this->ACK);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "Reserved:%d ", (int)this->Reserved);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "CHKSUM:%d ", (int)this->CHKSUM);
    strncat(pstr, temp, len-strlen(pstr));
}

void RDR_HDR_API::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->SRC);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->DST);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->OPCODE);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->MSGLEN);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->SEQNUM);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->SYNC);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->FLAGS);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->TIME);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->NSBC);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->ACK);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->Reserved);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->CHKSUM);
    strncat(pstr, temp, len-strlen(pstr));
}

