// File : demo.cpp 
#include "demo.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

demo::demo() {
    memset(&msg, 0, sizeof(msg));
}

bool demo::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool demo::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool demo::isValid() {
    return true;
}

void demo::ntoh() {
    msg.first_data.parts.x = ntohs(msg.first_data.parts.x);
    msg.first_data.parts.y = ntohs(msg.first_data.parts.y);
    msg.first_data.parts.z = ntohs(msg.first_data.parts.z);
    msg.first_data.parts.m = ntohs(msg.first_data.parts.m);
    msg.first_data.parts.n = ntohs(msg.first_data.parts.n);
    msg.first_data.combined = ntohs(msg.first_data.combined);
    msg.second_data.combined = ntohs(msg.second_data.combined);
    msg.third = ntohs(msg.third);
}

void demo::hton() {
    ntoh();
}

void demo::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void demo::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void demo::print() {
    print(stdout);
}

void demo::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void demo::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void demo::printBrief() {
    printBrief(stdout);
}

void demo::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void demo::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "demo:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.parts.x:%d ", (int)this->first_data.parts.x);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.parts.y:%d ", (int)this->first_data.parts.y);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.parts.z:%d ", (int)this->first_data.parts.z);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.parts.m:%d ", (int)this->first_data.parts.m);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.parts.n:%d ", (int)this->first_data.parts.n);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.combined):%d ", (int)this->first_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "second_data.combined):%d ", (int)this->second_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "third:%d ", (int)this->third);
    strncat(pstr, temp, len-strlen(pstr));
}

void demo::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.parts.x);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.parts.y);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.parts.z);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.parts.m);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.parts.n);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->second_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->third);
    strncat(pstr, temp, len-strlen(pstr));
}

