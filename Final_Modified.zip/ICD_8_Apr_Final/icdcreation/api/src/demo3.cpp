// File : demo3.cpp 
#include "demo3.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

demo3::demo3() {
    memset(&msg, 0, sizeof(msg));
}

bool demo3::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool demo3::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool demo3::isValid() {
    return true;
}

void demo3::ntoh() {
    msg.first_data.parts.y = ntohs(msg.first_data.parts.y);
    msg.first_data.combined = ntohs(msg.first_data.combined);
    msg.second_data.parts.x = ntohs(msg.second_data.parts.x);
    msg.second_data.parts.y = ntohs(msg.second_data.parts.y);
    msg.second_data.parts.z = ntohs(msg.second_data.parts.z);
    msg.second_data.combined = ntohs(msg.second_data.combined);
    msg.third = ntohs(msg.third);
    msg.hg_data.parts.ghjg = ntohs(msg.hg_data.parts.ghjg);
    msg.hg_data.combined = ntohs(msg.hg_data.combined);
}

void demo3::hton() {
    ntoh();
}

void demo3::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void demo3::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void demo3::print() {
    print(stdout);
}

void demo3::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void demo3::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void demo3::printBrief() {
    printBrief(stdout);
}

void demo3::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void demo3::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "demo3:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.parts.y:%d ", (int)this->first_data.parts.y);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "first_data.combined):%d ", (int)this->first_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "second_data.parts.x:%d ", (int)this->second_data.parts.x);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "second_data.parts.y:%d ", (int)this->second_data.parts.y);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "second_data.parts.z:%d ", (int)this->second_data.parts.z);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "second_data.combined):%d ", (int)this->second_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "third:%d ", (int)this->third);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "hg_data.parts.ghjg:%d ", (int)this->hg_data.parts.ghjg);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "hg_data.combined):%d ", (int)this->hg_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
}

void demo3::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.parts.y);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->first_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->second_data.parts.x);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->second_data.parts.y);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->second_data.parts.z);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->second_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->third);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->hg_data.parts.ghjg);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->hg_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
}

