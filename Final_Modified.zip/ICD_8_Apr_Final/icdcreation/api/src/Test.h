// File : test.h 
#ifndef __TEST_H__
#define __TEST_H__

#include <stdio.h>
#include <cstdint>

#pragma pack(1)

class test {
public:
    struct MsgBody {
        unsigned int msgid; // 16 bits 

        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    test();
};

#pragma pack()

#endif
