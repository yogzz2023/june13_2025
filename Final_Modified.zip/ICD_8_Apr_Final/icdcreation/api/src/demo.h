// File : demo.h 
#ifndef __DEMO_H__
#define __DEMO_H__

#include <stdio.h>
#include <cstdint>

#pragma pack(1)

class demo {
public:
    struct MsgBody {
        union first { 
            struct first_struct { 
                int8_t x:1; // 1 bits 
                int8_t y:2; // 2 bits 
                int8_t z:4; // 4 bits 
                int8_t m:8; // 8 bits 
                int8_t n:1; // 1 bits 
            } parts; 

            int16_t combined; // 16 bits 

        } first_data; 

        union second { 
            struct second_struct { 
            } parts; 

            int32_t combined; // 32 bits 

        } second_data; 

        bool third; // 8 bits 

        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    demo();
};

#pragma pack()

#endif
