// File : union_test3.h 
#ifndef __UNION_TEST3_H__
#define __UNION_TEST3_H__

#include <stdio.h>
#include <cstdint>

#pragma pack(1)

class union_test3 {
public:
    struct MsgBody {
        union first { 
            struct first_struct { 
                int8_t x:8; // 8 bits 
                int16_t z:16; // 16 bits 
                int8_t y:4; // 4 bits 
                int8_t m:4; // 4 bits 
            } parts; 

            int32_t combined; // 32 bits 
        } first_data; 

        union second { 
            struct second_struct { 
                int8_t x:2; // 2 bits 
                int8_t y:2; // 2 bits 
                int8_t z:4; // 4 bits 
                int8_t m:8; // 8 bits 
            } parts; 

            int32_t combined; // 16 bits 
        } second_data; 

        bool third; // 8 bits 

        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    union_test3();
};

#pragma pack()

#endif
