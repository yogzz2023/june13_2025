#include <cstring>
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <unistd.h>

using namespace std;

int main()
{
    WSADATA wsaData;
    if(WSAStartup(MAKEWORD(2,2), &wsaData) != 0){
        cout<<"Not starting up!";
        return -1;
    }

    // creating socket
    int serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket < 0) {
        perror("Socket creation failed");
        return -1;
    }

    // specifying the address
    sockaddr_in serverAddress{}, senderAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(8080);
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // binding socket.
    if (bind(serverSocket, (struct sockaddr*)&serverAddress,sizeof(serverAddress))){
        perror("Bind failed");
        return -1;
    }

    cout<<"Connection accepted waiting for data to recieve.....\n";

    socklen_t senderAddressLen = sizeof(senderAddress);
    unsigned char buf1[1024] = { 0 };
    
    int recvBytes1 = recvfrom(serverSocket, (char *)buf1, sizeof(buf1), 0, (struct sockaddr*)&senderAddress, &senderAddressLen);
    
    if(recvBytes1 < 0){
        perror("Receive failed");
        return -1;
    }
    
    cout<<"Msg recieved With byte count : " << recvBytes1 << endl << endl;
    cout<<buf1<<endl<<endl;

    cout<<"First BUFFER : ";
    cout<<*((unsigned short *)buf1)<<", ";
    cout<<*((unsigned short *)(sizeof(unsigned short *)+buf1))<<", ";
    cout<<*((unsigned short *)(sizeof(unsigned short *)+sizeof(unsigned short *)+buf1))<<", ";
    cout<<*((unsigned short *)(sizeof(unsigned short *)+sizeof(unsigned short *)+sizeof(unsigned short *)+buf1))<<endl;
    
    
    close(serverSocket);
    return 0;
}