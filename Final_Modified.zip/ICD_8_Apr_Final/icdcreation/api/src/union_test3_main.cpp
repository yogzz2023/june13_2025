#include<bits/stdc++.h>
#include "union_test3.h"

using namespace std;

int main()
{
    union_test3 test;

    test.msg.second_data.parts.x = 2;    // 10
    test.msg.second_data.parts.y = 3;    // 11
    test.msg.second_data.parts.z = 13;    // 1101
    test.msg.second_data.parts.m = 154;  // 10011010

    cout<< "Dec Value : " << +test.msg.second_data.combined << endl;
    cout<< "Hex Value : " << std::hex<<+(test.msg.second_data.combined) << endl;
    cout<< "Bit Value : " << std::bitset<16>(test.msg.second_data.combined) << endl;

    return 0;
}
