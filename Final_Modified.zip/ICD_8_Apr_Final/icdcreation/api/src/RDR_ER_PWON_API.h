// File : RDR_ER_PWON_API.h 
#ifndef __RDR_ER_PWON_API_H__
#define __RDR_ER_PWON_API_H__

#include <stdio.h>
#include "RDR_HDR_API.h"
#include "RDR_ER_PWON_SB.h"

#pragma pack(1)

class RDR_ER_PWON_API {
public:
    struct MsgBody {
        RDR_HDR_API HDR; // Number of bits 32 
        RDR_ER_PWON_SB ER_SB; // Number of bits 64 

        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    RDR_ER_PWON_API();
};

#pragma pack()

#endif
