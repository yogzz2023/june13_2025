// File : RDR_DRX_PWON_SB.cpp 
#include "RDR_DRX_PWON_SB.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

RDR_DRX_PWON_SB::RDR_DRX_PWON_SB() {
    memset(&msg, 0, sizeof(msg));
}

bool RDR_DRX_PWON_SB::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool RDR_DRX_PWON_SB::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool RDR_DRX_PWON_SB::isValid() {
    return true;
}

void RDR_DRX_PWON_SB::ntoh() {
    msg.SBLK_MSGID = ntohs(msg.SBLK_MSGID);
    msg.SBLK_LEN = ntohs(msg.SBLK_LEN);
    msg.ER_ID = ntohs(msg.ER_ID);
}

void RDR_DRX_PWON_SB::hton() {
    ntoh();
}

void RDR_DRX_PWON_SB::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void RDR_DRX_PWON_SB::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void RDR_DRX_PWON_SB::print() {
    print(stdout);
}

void RDR_DRX_PWON_SB::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void RDR_DRX_PWON_SB::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void RDR_DRX_PWON_SB::printBrief() {
    printBrief(stdout);
}

void RDR_DRX_PWON_SB::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void RDR_DRX_PWON_SB::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "RDR_DRX_PWON_SB:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "SBLK_MSGID:%d ", (int)this->SBLK_MSGID);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "SBLK_LEN:%d ", (int)this->SBLK_LEN);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "ER_ID:%d ", (int)this->ER_ID);
    strncat(pstr, temp, len-strlen(pstr));
}

void RDR_DRX_PWON_SB::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->SBLK_MSGID);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->SBLK_LEN);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->ER_ID);
    strncat(pstr, temp, len-strlen(pstr));
}

