// File : test.cpp 
#include "test.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

test::test() {
    memset(&msg, 0, sizeof(msg));
}

bool test::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool test::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool test::isValid() {
    return true;
}

void test::ntoh() {
    msg.msgid = ntohs(msg.msgid);
}

void test::hton() {
    ntoh();
}

void test::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void test::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void test::print() {
    print(stdout);
}

void test::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void test::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void test::printBrief() {
    printBrief(stdout);
}

void test::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void test::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "test:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "msgid:%d ", (int)this->msgid);
    strncat(pstr, temp, len-strlen(pstr));
}

void test::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->msgid);
    strncat(pstr, temp, len-strlen(pstr));
}

