#include <bits/stdc++.h>
#include "RDR_ANT_PWON_SB.h"
#include "RDR_PWON_Msg.h"

using namespace std;

int main()
{
    RDR_ANT_PWON_SB target;
    target.msg.SBLK_MSGID = 10;
    target.msg.SBLK_LEN = 16;
    target.msg.TRG_ID = 1;
    target.msg.TRM_ID = 2;

    unsigned char buf[1024];
    unsigned short sz;

    *((unsigned short *)buf) = target.msg.SBLK_MSGID;
    *((unsigned short *)(sizeof(unsigned short *)+buf)) = target.msg.SBLK_LEN;
    *((unsigned short *)(sizeof(unsigned short *)+sizeof(unsigned short *)+buf)) = target.msg.TRG_ID;
    *((unsigned short *)(sizeof(unsigned short *)+sizeof(unsigned short *)+sizeof(unsigned short *)+buf)) = target.msg.TRM_ID;

    sz =sizeof(buf);
    target.set(buf, sz);

    cout<<"End of RDR_ANT_PWON_SB program!"<<endl;

    RDR_PWON_Msg target1;
    target1.msg.ANT_PWON_SB = target;

    unsigned char buf1[1024];
    unsigned short sz1;

    *((RDR_ANT_PWON_SB *)buf1) = target1.msg.ANT_PWON_SB;
    sz = sizeof(buf1);
    target1.set(buf1, sz);

    cout<<"End of RDR_PWON_Msg program!"<<endl;

    return 0;
}