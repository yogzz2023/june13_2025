// File : harshita.h 
#ifndef __HARSHITA_H__
#define __HARSHITA_H__

#include <stdio.h>
#include <cstdint>

#pragma pack(1)

class harshita {
public:
    struct MsgBody {
        int test1; // 8 bits 
        union test2 { 
            struct test2_struct { 
                int u2:2; // 2 bits 
                bool u3:4; // 4 bits 
            } parts; 

            int8_t combined; // 8 bits 

        } test2_data; 


        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    harshita();
};

#pragma pack()

#endif
