// File : demo3.h 
#ifndef __DEMO3_H__
#define __DEMO3_H__

#include <stdio.h>
#include <cstdint>

#pragma pack(1)

class demo3 {
public:
    struct MsgBody {
        union first { 
            struct first_struct { 
                int8_t y:8; // 8 bits 
            } parts; 

            int8_t combined; // 8 bits 

        } first_data; 

        union second { 
            struct second_struct { 
                int8_t x:2; // 2 bits 
                int8_t y:2; // 2 bits 
                int8_t z:4; // 4 bits 
            } parts; 

            int8_t combined; // 8 bits 

        } second_data; 

        bool third; // 8 bits 
        union hg { 
            struct hg_struct { 
                hgjh ghjg:hg; // hg bits 
            } parts; 

            inthg_t combined; // hg bits 

        } hg_data; 


        // Print Functions
        void print(char pstr[], int len);
        void printBrief(char pstr[], int len);
    } msg;

    bool set(unsigned char msg[], unsigned short &size);
    bool decode(unsigned char msg[], unsigned short size);
    bool isValid();
    void ntoh();
    void hton();
    void print(char pstr[], int len);
    void print(FILE *fp);
    void print();
    void printBrief(char pstr[], int len);
    void printBrief(FILE *fp);
    void printBrief();
    void printMin(char pstr[], int len);
    demo3();
};

#pragma pack()

#endif
