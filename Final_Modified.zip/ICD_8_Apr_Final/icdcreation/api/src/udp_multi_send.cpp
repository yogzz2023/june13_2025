#include <cstring>
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <unistd.h>
#include "RDR_ANT_PWON_API.h"

using namespace std;

int main()
{
    WSADATA wsaData;
    if(WSAStartup(MAKEWORD(2,2), &wsaData) != 0){
        cout<<"Not Starting Up!";
        return -1;
    }

    // Creating Socket
    int clientSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if(clientSocket < 0){
        perror("Socket creation failed");
        return -1;
    }

    // Specifying address
    sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(9000);
    serverAddress.sin_addr.s_addr = inet_addr("169.254.26.2");
    // serverAddress.sin_addr.s_addr = inet_addr("169.254.26.0");

    // Sending connection request
    if(connect(clientSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0){
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    cout<<"Connected to server. Sending data..."<<endl;

    RDR_ANT_PWON_SB ant_sb;
    ant_sb.msg.SBLK_MSGID = 0x0011;
    ant_sb.msg.SBLK_LEN = 8;
    ant_sb.msg.TRG_ID = 1;
    ant_sb.msg.TRM_ID = 2; 

    // RDR_HDR_API hdr;
    // hdr.msg.OPCODE = 0x001;
    // hdr.msg.MSGLEN = 12;

    // RDR_ANT_PWON_API api;
    // api.msg.HDR.msg.MSGLEN = 8;
    // api.msg.ANT_SB = ant_sb;

    const char buf1[1024]={0};
    *((unsigned short *)buf1) = ant_sb.msg.SBLK_MSGID;
    *((unsigned short *)(sizeof(unsigned short *)+buf1)) = ant_sb.msg.SBLK_LEN;
    *((unsigned short *)(sizeof(unsigned short *)+sizeof(unsigned short *)+buf1)) = ant_sb.msg.TRG_ID;
    *((unsigned short *)(sizeof(unsigned short *)+sizeof(unsigned short *)+sizeof(unsigned short *)+buf1)) = ant_sb.msg.TRM_ID;

    

    int bytes_sent1 = sendto(clientSocket, (char *)buf1, sizeof(buf1), 0, (struct sockaddr*)&serverAddress,sizeof(serverAddress));
    
    cout << "Sent_1 " << bytes_sent1 << " bytes" <<endl;
    
    // closing socket
    close(clientSocket);

    return 0;

}
