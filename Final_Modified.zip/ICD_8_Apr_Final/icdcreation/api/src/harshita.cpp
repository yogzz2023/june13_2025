// File : harshita.cpp 
#include "harshita.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <iostream>
#include <winsock2.h>
using namespace std;

harshita::harshita() {
    memset(&msg, 0, sizeof(msg));
}

bool harshita::set(unsigned char msgbuf[], unsigned short &size) {
    size = sizeof(msg);
    bool valid = true;
    hton();
    memcpy(msgbuf, &msg, sizeof(msg));
    ntoh();
    return valid;
}

bool harshita::decode(unsigned char msgbuf[], unsigned short size) {
    int s=0;
    size_t minSize=(sizeof(msg) < size)?sizeof(msg):size;
    memcpy(&msg, msgbuf, minSize);
    s+=sizeof(msg);
    ntoh();
    bool valid=true;
    if(s!=size) valid=false;
    if(!isValid()) valid=false;
    return valid;
}

bool harshita::isValid() {
    return true;
}

void harshita::ntoh() {
    msg.test1 = ntohs(msg.test1);
    msg.test2_data.parts.u2 = ntohs(msg.test2_data.parts.u2);
    msg.test2_data.parts.u3 = ntohs(msg.test2_data.parts.u3);
    msg.test2_data.combined = ntohs(msg.test2_data.combined);
}

void harshita::hton() {
    ntoh();
}

void harshita::print(char pstr[], int len) {
    msg.print(pstr, len);
}

void harshita::print(FILE *fp) {
    const int len = 4096;
    char str[len];
    print(str, len);
    fprintf(fp, "%s", str);
}

void harshita::print() {
    print(stdout);
}

void harshita::printBrief(char pstr[], int len) {
    msg.printBrief(pstr, len);
}

void harshita::printBrief(FILE *fp) {
    const int len = 4096;
    char str[len];
    printBrief(str, len);
    fprintf(fp, "%s", str);
}

void harshita::printBrief() {
    printBrief(stdout);
}

void harshita::printMin(char pstr[], int len) {
    printBrief(pstr, len);
    char last = ' ';
    for (int i = len - 1; i > 0; i--) {
        if (pstr[i] == last && last == ' ') {
            for (int j = i + 1; j < len; j++) pstr[j - 1] = pstr[j];
        }
        last = pstr[i];
    }
}

void harshita::MsgBody::print(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    snprintf(temp, len, "harshita:");
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "test1:%d ", (int)this->test1);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "test2_data.parts.u2:%d ", (int)this->test2_data.parts.u2);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "test2_data.parts.u3:%d ", (int)this->test2_data.parts.u3);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "test2_data.combined):%d ", (int)this->test2_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
}

void harshita::MsgBody::printBrief(char pstr[], int len) {
    char temp[len];
    temp[0] = '\0';
    strncpy(pstr, "", len);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->test1);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->test2_data.parts.u2);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->test2_data.parts.u3);
    strncat(pstr, temp, len-strlen(pstr));
    snprintf(temp, len, "%d ", (int)this->test2_data.combined);
    strncat(pstr, temp, len-strlen(pstr));
}

