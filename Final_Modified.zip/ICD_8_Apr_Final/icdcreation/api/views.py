from rest_framework.decorators import action
import json
from rest_framework import serializers
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Item,Icd
from django.http import JsonResponse
from collections import defaultdict
from .validation import Validator, SerializeData
from .files_creation import FilesCreation
import os

class ClassCreation(APIView):
    def post(self, request):
        # Validate request data
        validator = Validator()
        data = validator.parse_to_json(request.data) # Parse the JSON data if request.data is a string
        
        # Validate if data is list or not empty
        if not validator.checking_formate(data):
            return Response(
                {"error": "Request data must be a non-empty list."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # print("data : ", data)

        # Serialized the validated data
        ser_Data =SerializeData()
        serialized_data =ser_Data.serializeData(data, "post", "")

        # Return a response with all the saved items (or a success message)
        return Response(
            {"message": "Data created successfully", "data": serialized_data},
            status=status.HTTP_201_CREATED
        )

    def get(self, request):
        # Retrieve the class_name(s) from query parameters (can be a list)
        class_names = request.query_params.getlist('class_name', None)
        sort_order = request.query_params.get('sort', 'desc')  # Default sort to 'desc'
        only_class = request.query_params.get('only_class', None)  # Check if only_class is passed

        if only_class:
            # If 'only_class' is passed, return only unique class names, sorted by 'updated_at'
            if sort_order == 'asc':
                # Sort in ascending order
                class_names_sorted = Icd.objects.values('class_name').distinct().order_by('updated_at')
            else:
                # Default or descending order
                class_names_sorted = Icd.objects.values('class_name').distinct().order_by('-updated_at')

            # Return only unique class names as a list
            unique_class_names = list(dict.fromkeys([item['class_name'] for item in class_names_sorted]))  # Remove duplicates
            return Response(unique_class_names, status=status.HTTP_200_OK)

        if class_names:
                # Split the comma-separated values into a list
            class_names = class_names[0].split(',')

            # Filter the items by the class_names list
            items = Icd.objects.filter(class_name__in=class_names)
        else:
            # If no class_name is provided, return all items
            items = Icd.objects.all()

        if not items:
            # If no items are found, return an error response
            return Response(
                {"detail": "No records found for the provided class_name(s)"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Initialize a dictionary to hold data grouped by class_name dynamically
        class_data = defaultdict(list)

        # Group items by class_name dynamically
        for item in items:
            class_data[item.class_name].append({
                "id": item.id,
                "parameter": item.parameter,
                "data_type": item.data_type,
                "bit_count": item.bit_count,
                "min_value": item.min_value,
                "max_value": item.max_value,
                "default": item.default,
                "created_at": item.created_at,
                "updated_at": item.updated_at,
                "deleted_at": item.deleted_at,
                "union_data": item.union_data
            })

        # Return the grouped data as a response
        return Response(dict(class_data), status=status.HTTP_200_OK)
    
class LibraryCreation(APIView):
    def post(self, request):
        # Validate request data
        validator = Validator()
        class_names = validator.parse_to_json(request.data) # Parse the JSON data if request.data is a string
        
        # print("request.data : ", request.data)
        
        # Validate if data is list or not empty
        if not validator.checking_formate(class_names):
            return Response(
                {"error": "Request data must be a non-empty list."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Collect invalid items
        invalid_items, check= validator.invalid_items(class_names) 
        if check == True:
            return Response(
                {"detail": "Invalid data type.", "invalid_items": invalid_items},
                status=status.HTTP_400_BAD_REQUEST  # Use 400 for bad input
            )
        
        # Validate if class name are available or not
        found_items, response = validator.invalid_class(class_names)
        if response.status_code == 404 or response.status_code == 400:
            return Response(
                {"detail": "Missing class_name(s) found in the request data."},
                status=response.status_code,  # 400 is more appropriate for missing data
            )
                
        # Initialize a dictionary to hold data grouped by class_name dynamically
        class_data = defaultdict(list)
        
        # Group items by class_name dynamically
        for item in found_items:
            class_data[item.class_name].append({
                "id": item.id,
                "parameter": item.parameter,
                "data_type": item.data_type,
                "bit_count": item.bit_count,
                "min_value": item.min_value,
                "max_value": item.max_value,
                "default": item.default,
                "data_type_type": item.data_type_type,
                "union_data": item.union_data
            })
            
        # Create .h and .cpp files
        FilesCreation().create_header_files(dict(class_data))
        FilesCreation().create_cpp_file(dict(class_data))
        
        return Response({"Library created!"}, status=status.HTTP_201_CREATED)   

class ClassEdition(APIView):
    def get(self, request):
        validator = Validator()
        class_names = validator.parse_to_json(request.data) # Parse the JSON data if request.data is a string
        # print("Data coming from frontend : ", class_names)

        if class_names:
            class_names = class_names[0].split(',')
            items = Icd.objects.filter(class_name__in=class_names)
        else:
            return Response(
                {"detail": "No records found for the provided class_name(s)"},
                status=status.HTTP_404_NOT_FOUND
            )

        class_data = defaultdict(list)
        for item in items:
            class_data[item.class_name].append({
                "id": item.id,
                "parameter": item.parameter,
                "data_type": item.data_type,
                "bit_count": item.bit_count,
                "min_value": item.min_value,
                "max_value": item.max_value,
                "default": item.default,
                "created_at": item.created_at,
                "updated_at": item.updated_at,
                "deleted_at": item.deleted_at,
                "union_data": item.union_data
            })

        return Response(class_data, status=status.HTTP_200_OK)

    def put(self, request):
        validator = Validator()
        class_data = validator.parse_to_json(request.data) 

        class_name = class_data[0]
        data = class_data[1]
        
        if not validator.checking_formate(data):
            return Response(
                {"error": "Request data must be a non-empty list."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # print("data : ", data)

        # Serialized the validated data
        ser_Data =SerializeData()
        serialized_data =ser_Data.serializeData(data, "put", class_name)
        
        return Response(
            {"message": "Class Updated", "data": serialized_data}, 
            status=status.HTTP_201_CREATED
        )    
