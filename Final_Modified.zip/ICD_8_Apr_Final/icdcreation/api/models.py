from django.db import models

class Item(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Icd(models.Model):
    class_name = models.CharField(max_length=250, blank=False)  # Required field
    parameter = models.CharField(max_length=250, blank=False)   # Required field
    data_type = models.CharField(max_length=250, blank=False)   # Required field
    bit_count = models.CharField(max_length=250, blank=True)    # Optional field
    min_value = models.CharField(max_length=250, blank=False)   # Required field
    max_value = models.CharField(max_length=250, blank=False)   # Required field
    default = models.CharField(max_length=250, blank=True)      # Optional field
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    data_type_type = models.CharField(max_length=250, blank=True)
    union_data = models.CharField(max_length=250, blank=True)

    def __str__(self):
        return self.class_name