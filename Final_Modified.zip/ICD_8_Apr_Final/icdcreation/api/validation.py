from rest_framework.decorators import action
import json
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Item,Icd
from .serializers import ItemSerializer,IcdSerializer
from django.http import JsonResponse
from collections import defaultdict

class Validator():
    def __init__(self):
        pass
    
    def parse_to_json(self, data):
        # print("iside parse_to_json : ", data)
        validated_data = data
        if isinstance(data, str):
            try:
                validated_data = json.loads(data)  # Parse string to JSON (Python dict/list)
            except json.JSONDecodeError:
                return Response({"error": "Invalid JSON format."}, status=status.HTTP_400_BAD_REQUEST)
        
        return validated_data    
    
    # If the request data is not a list or is empty, return a 400 Bad Request
    def checking_formate(self, data):
        # print("iside checking_formate : ", data)
        if not isinstance(data, list) or not data:
            return False
        return True
    
    # Collect invalid class items        
    def invalid_items(self, data):
        # print("iside invalid_items : ", data)
        if not all(isinstance(item, str) for item in data):
            invalid_items = [item for item in data if not isinstance(item, str)]  # Collect invalid items
            return invalid_items, True
        return [], False  
    
    # Validate if class name are available or not
    def invalid_class(self, class_names):
        # print("inside invalid_class :", class_names)
        if class_names:
            # Filter the items by the class_names list
            found_items = Icd.objects.filter(class_name__in=class_names)
            found_class_names = list(found_items.values_list("class_name", flat=True))

            # Find the missing class names
            missing_class_names = list(set(class_names) - set(found_class_names))
            
            if missing_class_names:
                # If some class names are not found, return them in the response
                return missing_class_names, Response(
                    {
                        "detail": "Some class_name(s) not found in the database.",
                        "missing_class_names": missing_class_names,
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )
        else:
            # If no class_name is provided, return error
            return [], Response(
                {"detail": "No class_name(s) found in the request data."},
                status=status.HTTP_400_BAD_REQUEST,  # 400 is more appropriate for missing data
            )

        # If no class names are found
        if not found_items:
            return [], Response(
                {"detail": "No records found for the provided class_name(s)."},
                status=status.HTTP_404_NOT_FOUND,
            )  
        
        # If all class names are found, return the found items
        return found_items , Response({"Library created!"}, status=status.HTTP_200_OK)       
            
class SerializeData:
    def __init__(self):
        print("inside SerializeData")
        
    def serializeData(self, data, api, class_name):
        self.serialized_data = []
        index =0
 
        print("api from serialization....", api) 
        # Iterate through each item in the request data (which is a list)
        if api=="post":
            for item in data:
                # Check if class_name already exists
                if index == 0 and Icd.objects.filter(class_name=item['class_name']).exists():
                    return Response(
                        {"error": f"Class name '{item['class_name']}' already exists."},
                        status=status.HTTP_400_BAD_REQUEST
                    )
   
                index+=1
                
                # Serialize the data
                self.saveData(item)
        else:
            Icd.objects.filter(class_name=class_name).delete()
           
            for item in data:
                self.saveData(item)

        return self.serialized_data            

    def saveData(self, data):
        serializer = IcdSerializer(data=data)
            
        if serializer.is_valid():
            serializer.save()  # Save the item to the database
            self.serialized_data.append(serializer.data)
        else:
            # If one of the items is invalid, return a 400 Bad Request with errors
            return Response(
                {"error": "Validation failed", "details": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )    
         
